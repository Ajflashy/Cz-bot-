package math

typealias Function1<T> = (a: T) -> T
typealias Function2<T> = (a: T, b: T) -> T